#!/bin/bash

echo "collecting system logs..."

cp /var/log/auth.log ../logs/
cp /var/log/syslog ../logs/

echo "logs collection successfully."

