#!/bin/bash

echo "Setting up firewall..."

sudo apt update

sudo apt install ufw -y

sudo ufw default deny incoming 

sudo ufw default allow outgoing

sudo ufw allow ssh

sudo ufw enable

echo "Firewall setup completed."
