import os 

def disable_root_login():
  print("Disabling root login...")
  os.system("sudo sed -i 's/PermitRootLogin yes/PermitRootLogin no/' /etc/ssh/ssh_config")
  os.system("sudo systemctl restart ssh")
  print("Root login disabled.\n")

def update_system():
  print("Updating system...")
  os.system("sudo apt update && sudo apt upgrade -y")
  print("System updated.\n")

while True:
  print("=== Linux Server Hardening Tool ===")
  print("1. Disable Root Login")
  print("2. Update & Upgrade System")
  print("3. Exit")

  choice = input("Enter your choice: ")

  if choice == "1":
      disable_root_login()
  elif choice == "2":
      update_system()
  elif choice == "3":
      break
  else:
      print("Invalid choice.\n")
