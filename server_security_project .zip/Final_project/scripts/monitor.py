import os 
import re

failed_logins = 0

with open("../logs/auth.log", "r") as file:
      for line in file:
          if "Failed password" in line:
              failed_logins += 1


print("Failed login attempts:", failed_logins)

if failed_logins > 3:
    print("ALERT: Possible brute-force attack detected!")
else:
   print("System is secure.")

status = "System is secure."
print("status")

if not os.path.exists("../output"):
        os.makedirs("../output")


with open("../output/report.txt", "w") as report:
      report.write("Failed login attempts: " + str(failed_logins) + "\n")
      report.write(status)
